package com.example.figuras.figura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FiguraApplicationTests {

	@Test
	void contextLoads() {
	}

}
