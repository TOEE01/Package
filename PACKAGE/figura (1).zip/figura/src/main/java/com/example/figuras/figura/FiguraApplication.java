package com.example.figuras.figura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FiguraApplication {

	public static void main(String[] args) {
		SpringApplication.run(FiguraApplication.class, args);
	}

}
